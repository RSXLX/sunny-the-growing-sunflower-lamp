"""Dependency-free, deterministic crown geometry and binary STL/GLB utilities.
Units in generated STL: millimetres. Not a structural or thermal certification.
"""
from __future__ import annotations
import hashlib, json, math, struct
from pathlib import Path

INTERFACE = {
    'version': 'bloom-clamp-v1', 'units': 'mm', 'crown_bore_diameter': 76.0,
    'head_pilot_diameter': 75.0, 'bearing_zone_radii': [38.0, 43.0],
    'bearing_thickness': 4.0, 'max_outer_diameter': 196.0,
    'max_depth': 24.0, 'retainer_outer_diameter': 86.0,
    'retainer_screw_bcd': 70.0, 'retainer_screws': '3 x M3 through bolts + washers + nuts',
    'nfc_tag_center_xy': [0.0, -55.0], 'nfc_tag_max_size': [22.0, 22.0],
    'qualification': 'prototype; fit, retention, RF and thermal tests required',
}

def normal(a, b, c):
    u=[b[i]-a[i] for i in range(3)]; v=[c[i]-a[i] for i in range(3)]
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
    length=math.sqrt(sum(x*x for x in n)) or 1
    return tuple(x/length for x in n)

def write_stl(path: Path, triangles):
    triangles=list(triangles)
    with path.open('wb') as f:
        f.write(b'BLOOM / millimetres / prototype only'.ljust(80,b' '))
        f.write(struct.pack('<I',len(triangles)))
        for a,b,c in triangles:
            f.write(struct.pack('<12fH',*normal(a,b,c),*a,*b,*c,0))

def read_stl(path: Path):
    data=path.read_bytes()
    if len(data)>=84:
        n=struct.unpack_from('<I',data,80)[0]
        if len(data)==84+50*n:
            return [[tuple(struct.unpack_from('<3f',data,84+i*50+12+j*12)) for j in range(3)] for i in range(n)]
    import re
    vertices=[tuple(map(float,m)) for m in re.findall(r'vertex\s+([\-+.\deE]+)\s+([\-+.\deE]+)\s+([\-+.\deE]+)',data.decode())]
    if len(vertices)%3: raise ValueError('Malformed STL')
    return [vertices[i:i+3] for i in range(0,len(vertices),3)]

def crown_parameters(prompt: str, theme: str, seed: int | None=None):
    seed=seed if seed is not None else int.from_bytes(hashlib.sha256((prompt+theme).encode()).digest()[:4],'big')
    digest=hashlib.sha256(f'{prompt}|{theme}|{seed}'.encode()).digest()
    lobes={'sunflower':12,'forest':8,'stars':7}.get(theme,12)+(digest[0]%3-1)
    return {'theme':theme,'seed':seed,'lobes':lobes,
            'root_radius':70.0,'tip_radius':88.0+int.from_bytes(digest[1:3],'big')/65535*8,
            'phase':int.from_bytes(digest[3:5],'big')/65535*math.tau/lobes,
            'inner_radius':38.0,'thickness':4.0}

def crown_triangles(params, segments=240, rings=8):
    n=params['lobes']; root=params['root_radius']; tip=params['tip_radius']; theme=params['theme']
    layers=[]
    for j in range(rings+1):
        layer=[]
        for i in range(segments):
            a=math.tau*i/segments
            angle=a+params.get('phase',0)
            wave=(math.cos(n*angle)+1)/2
            if theme=='stars': wave=1-abs((n*angle/math.pi)%2-1)
            elif theme=='forest': wave=wave**1.4
            else: wave=wave**0.65
            edge=root+(tip-root)*wave
            r=38.0 if j==0 else 43.0+(edge-43.0)*(j-1)/(rings-1)
            # Guaranteed flat annular clamp interface; organic relief outside r=43.
            h=4+max(0,min(1,(r-43)/12))*3*(0.4+0.6*wave)
            layer.append(((r*math.cos(a),r*math.sin(a),0.0),(r*math.cos(a),r*math.sin(a),h)))
        layers.append(layer)
    out=[]
    for j in range(rings):
        for i in range(segments):
            k=(i+1)%segments
            a,b,c,d=layers[j][i],layers[j+1][i],layers[j+1][k],layers[j][k]
            out.extend([(a[1],b[1],c[1]),(a[1],c[1],d[1]),(a[0],c[0],b[0]),(a[0],d[0],c[0])])
    for i in range(segments):
        k=(i+1)%segments
        a,b=layers[0][i],layers[0][k]
        out.extend([(a[0],a[1],b[1]),(a[0],b[1],b[0])])
        a,b=layers[-1][i],layers[-1][k]
        out.extend([(a[0],b[0],b[1]),(a[0],b[1],a[1])])
    return out

def inspect_mesh(triangles):
    vertices=[v for t in triangles for v in t]
    bounds=[[min(v[i] for v in vertices) for i in range(3)],[max(v[i] for v in vertices) for i in range(3)]]
    edges={}; volume=0.0; degenerate=0
    for tri in triangles:
        a,b,c=tri
        volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
        pts=[tuple(round(x,4) for x in v) for v in tri]
        if len(set(pts))<3: degenerate+=1
        for i in range(3):
            edge=tuple(sorted((pts[i],pts[(i+1)%3]))); edges[edge]=edges.get(edge,0)+1
    return {'triangles':len(triangles),'bounds_mm':bounds,'dimensions_mm':[round(bounds[1][i]-bounds[0][i],3) for i in range(3)],
            'watertight_edge_count':all(v==2 for v in edges.values()),'degenerate_faces':degenerate,
            'signed_volume_mm3':round(volume,2),'physical_validation':'NOT_PERFORMED',
            'not_checked':['minimum wall thickness','self intersection','heat resistance','retention force','optics','NFC read range']}

def make_crown(directory: Path, prompt: str, theme: str, seed=None):
    directory.mkdir(parents=True,exist_ok=True)
    params=crown_parameters(prompt,theme,seed); triangles=crown_triangles(params)
    write_stl(directory/'crown.stl',triangles)
    report=inspect_mesh(triangles)
    (directory/'parameters.json').write_text(json.dumps(params,indent=2))
    (directory/'mesh-report.json').write_text(json.dumps(report,indent=2))
    (directory/'interface.json').write_text(json.dumps(INTERFACE,indent=2))
    return params,report

# Minimal uncompressed GLB reader. Explicitly reject Draco, sparse accessors and
# animations rather than silently export damaged geometry. Scene transforms honored.
def glb_triangles(path: Path):
    data=path.read_bytes()
    if len(data)<20 or data[:4]!=b'glTF': raise ValueError('Not a GLB')
    version,total=struct.unpack_from('<II',data,4)
    if version!=2 or total!=len(data): raise ValueError('Unsupported or truncated GLB')
    pos=12; doc=None; binary=b''
    while pos+8<=len(data):
        size,kind=struct.unpack_from('<II',data,pos); chunk=data[pos+8:pos+8+size]; pos+=8+size
        if kind==0x4E4F534A: doc=json.loads(chunk)
        elif kind==0x004E4942: binary=chunk
    if not doc or not binary: raise ValueError('Embedded GLB buffer required')
    def accessor(idx):
        a=doc['accessors'][idx]
        if 'sparse' in a: raise ValueError('Sparse accessor requires Blender conversion')
        view=doc['bufferViews'][a['bufferView']]
        if view.get('buffer',0)!=0: raise ValueError('External buffers unsupported')
        fmt,size={5126:('f',4),5125:('I',4),5123:('H',2),5121:('B',1)}[a['componentType']]
        count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        offset=view.get('byteOffset',0)+a.get('byteOffset',0); stride=view.get('byteStride',count*size)
        if a['count']>1500000: raise ValueError('Mesh too large')
        return [struct.unpack_from('<'+fmt*count,binary,offset+i*stride) for i in range(a['count'])]
    identity=[1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
    def mul(a,b): return [sum(a[k*4+r]*b[c*4+k] for k in range(4)) for c in range(4) for r in range(4)]
    def matrix(node):
        if 'matrix' in node: return node['matrix']
        x,y,z,w=node.get('rotation',[0,0,0,1]); sx,sy,sz=node.get('scale',[1,1,1]); tx,ty,tz=node.get('translation',[0,0,0])
        return [(1-2*(y*y+z*z))*sx,2*(x*y+z*w)*sx,2*(x*z-y*w)*sx,0,
                2*(x*y-z*w)*sy,(1-2*(x*x+z*z))*sy,2*(y*z+x*w)*sy,0,
                2*(x*z+y*w)*sz,2*(y*z-x*w)*sz,(1-2*(x*x+y*y))*sz,0,tx,ty,tz,1]
    def visit(index,parent,depth=0):
        if depth>64: raise ValueError('Invalid scene hierarchy')
        node=doc['nodes'][index]; mat=mul(parent,matrix(node)); output=[]
        if 'skin' in node: raise ValueError('Skinned model requires Blender conversion')
        if 'mesh' in node:
            for prim in doc['meshes'][node['mesh']]['primitives']:
                if prim.get('mode',4)!=4 or 'KHR_draco_mesh_compression' in prim.get('extensions',{}): raise ValueError('Only uncompressed triangle meshes supported')
                vs=accessor(prim['attributes']['POSITION']); ids=[x[0] for x in accessor(prim['indices'])] if 'indices' in prim else list(range(len(vs)))
                def transform(v): return tuple(sum(mat[k*4+r]*v[k] for k in range(3))+mat[12+r] for r in range(3))
                for i in range(0,len(ids)-2,3): output.append([transform(vs[ids[i+j]]) for j in range(3)])
        for c in node.get('children',[]): output.extend(visit(c,mat,depth+1))
        return output
    roots=doc.get('scenes',[{}])[doc.get('scene',0)].get('nodes',[])
    result=[]
    for n in roots: result.extend(visit(n,identity))
    if not result: raise ValueError('No geometry found')
    return result
