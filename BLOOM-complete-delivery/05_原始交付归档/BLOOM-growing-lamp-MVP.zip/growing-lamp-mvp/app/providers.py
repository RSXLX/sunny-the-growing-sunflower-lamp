"""Tripo REST adapter with TLS verification, bounded downloads and no blind paid retries."""
from __future__ import annotations
import ipaddress, json, os, socket, urllib.error, urllib.parse, urllib.request
from pathlib import Path

class SubmissionUnknown(Exception): pass

class Tripo:
    def __init__(self):
        self.key=os.getenv('TRIPO_API_KEY','').strip()
        self.base=os.getenv('TRIPO_API_BASE','https://api.tripo3d.ai/v2/openapi').rstrip('/')
        parsed=urllib.parse.urlparse(self.base)
        if parsed.scheme!='https' or parsed.hostname not in {'api.tripo3d.ai','api.tripo3d.com'} or parsed.username or parsed.password:
            raise ValueError('TRIPO_API_BASE must use an official HTTPS API host')
    def request(self,method,path,payload=None):
        request=urllib.request.Request(self.base+path,data=json.dumps(payload).encode() if payload is not None else None,
            headers={'Authorization':'Bearer '+self.key,'Content-Type':'application/json','User-Agent':'Bloom-MVP/1.0'},method=method)
        with urllib.request.urlopen(request,timeout=30) as response:
            body=response.read(2*1024*1024)
        doc=json.loads(body)
        if doc.get('code',0)!=0: raise RuntimeError('Tripo returned code '+str(doc.get('code')))
        return doc['data']
    def create(self,prompt):
        if not self.key:raise ValueError('TRIPO_API_KEY is not configured')
        payload={'type':'text_to_model','prompt':prompt,'texture':False,'pbr':False,'face_limit':20000,
                 'model_version':os.getenv('TRIPO_MODEL_VERSION','v2.5-20250123')}
        try:return self.request('POST','/task',payload)['task_id']
        except urllib.error.HTTPError as exc:
            if 400<=exc.code<500:raise RuntimeError(f'Tripo rejected the request (HTTP {exc.code}); check key, model and balance') from exc
            raise SubmissionUnknown('Request result unknown. Check Tripo console and attach the task ID; do not blindly regenerate.') from exc
        except Exception as exc:raise SubmissionUnknown('Request result unknown. Check Tripo console and attach the task ID; do not blindly regenerate.') from exc
    def poll(self,task):
        if not task or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in task):raise ValueError('Invalid task id')
        return self.request('GET','/task/'+task)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def download_model(url: str,target: Path,max_bytes=50*1024*1024):
    opener=urllib.request.build_opener(NoRedirect)
    for _ in range(5):
        parsed=urllib.parse.urlparse(url)
        if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password:raise ValueError('Only HTTPS model files are accepted')
        for address in socket.getaddrinfo(parsed.hostname,parsed.port or 443,type=socket.SOCK_STREAM):
            if not ipaddress.ip_address(address[4][0]).is_global:raise ValueError('Private network asset URL rejected')
        try:
            with opener.open(urllib.request.Request(url,headers={'User-Agent':'Bloom-MVP/1.0'}),timeout=60) as response:
                if int(response.headers.get('Content-Length','0'))>max_bytes:raise ValueError('Model exceeds download limit')
                tmp=target.with_suffix('.partial'); total=0
                try:
                    with tmp.open('wb') as f:
                        while True:
                            chunk=response.read(65536)
                            if not chunk:break
                            total+=len(chunk)
                            if total>max_bytes:raise ValueError('Model exceeds download limit')
                            f.write(chunk)
                    tmp.replace(target)
                finally:tmp.unlink(missing_ok=True)
                return
        except urllib.error.HTTPError as exc:
            if exc.code in (301,302,303,307,308) and exc.headers.get('Location'):
                url=urllib.parse.urljoin(url,exc.headers['Location']);continue
            raise
    raise ValueError('Too many asset redirects')
