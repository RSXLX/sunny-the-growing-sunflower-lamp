"""Application service: permission boundaries, durable commands and generation jobs."""
from __future__ import annotations
import io, json, os, re, secrets, shutil, sqlite3, subprocess, sys, threading, time, zipfile
from pathlib import Path
from .geometry import make_crown, INTERFACE, glb_triangles, write_stl, inspect_mesh
from .providers import Tripo, SubmissionUnknown, download_model
from .store import Store, uid, stamp, hash_secret

THEMES={'sunflower','forest','stars'}
ROOT=Path(__file__).resolve().parent.parent

class APIError(Exception):
    def __init__(self,status,message): self.status=status; self.message=message

def text(value,label='text',minimum=1,maximum=1000):
    if not isinstance(value,str) or not minimum<=len(value.strip())<=maximum:raise APIError(400,f'{label} 长度须为 {minimum}–{maximum} 字符')
    return value.strip()

def theme(value):
    if value not in THEMES:raise APIError(400,'未知主题')
    return value

def integer(value,minimum,maximum,label):
    if isinstance(value,bool) or not isinstance(value,int) or not minimum<=value<=maximum:raise APIError(400,f'{label} 超出范围')
    return value

class Service:
    def __init__(self,directory,demo=True):
        self.store=Store(directory); self.data=self.store.directory; self.demo=demo
        (self.data/'assets').mkdir(exist_ok=True)
        self.stop_event=threading.Event(); self.job_lock=threading.Lock(); self.worker=None; self.sim_worker=None
        if demo:self.seed()
        # A process may have crashed after the provider accepted a paid POST. Never repeat it blindly.
        self.store.execute("UPDATE designs SET status='submission_unknown',error='进程在提交期间中断，请从 Tripo 控制台核对并恢复任务 ID' WHERE status='submitting' AND task_id IS NULL")
        self.store.execute("UPDATE designs SET status='polling' WHERE task_id IS NOT NULL AND status IN ('submitting','generating','downloading')")
        self.store.execute("UPDATE designs SET status='queued' WHERE provider='parametric' AND status='generating'")
    def seed(self):
        alice=self.store.user('alice@bloom.local','嘉一','BloomDemo!2026')
        bob=self.store.user('bob@bloom.local','林间来信','BloomDemo!2026')
        if self.store.one('SELECT id FROM designs LIMIT 1'):return
        created=stamp()
        seeds=[(alice,'初见 · 向日葵','刚搬进来的房间，需要一束温暖而安静的光。','sunflower',11,0),
               (alice,'第一晚 · 森林','搬来这里的第一晚，窗外有一棵很大的树。我喜欢那片树影。','forest',21,1),
               (bob,'来信 · 星夜','把散步时抬头看见的星星，留在自己的房间里。','stars',32,1)]
        for i,(owner,title,prompt,th,seed,public) in enumerate(seeds):
            mid=uid();self.store.execute('INSERT INTO memories VALUES(?,?,?,?,?,?)',(mid,owner,title,prompt,th,created-(3-i)*86400))
            did=uid(); asset=f'assets/{did}'; make_crown(self.data/asset,prompt,th,seed)
            self.store.execute('INSERT INTO designs(id,owner,title,prompt,theme,seed,memory_id,provider,status,progress,asset,public,review_note,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                (did,owner,title,prompt,th,seed,mid,'parametric','reviewed',100,asset,public,'团队参数化样例，数字网格检查完成；没有实物验证。',created-(3-i)*86400))
            if owner==alice:
                iid=uid();self.store.execute('INSERT INTO instances(id,owner,design_id,name,tag_payload,stage,simulated,created) VALUES(?,?,?,?,?,?,?,?)',
                    (iid,owner,did,title+' / 演示件','BLM1:'+iid,'bound',1,created))
        for owner,name in [(alice,'我的向日葵'),(bob,'林间的灯')]:
            did,_=self.store.device(owner,name,'simulator')
            instance=self.store.one('SELECT i.*,d.theme FROM instances i JOIN designs d ON d.id=i.design_id WHERE i.owner=? ORDER BY i.created LIMIT 1',(owner,))
            state={'power':True,'brightness':45,'projection':20,'theme':instance['theme'] if instance else 'stars','instance_id':instance['id'] if instance else None,'temperature_c':27.0}
            self.store.execute('UPDATE devices SET reported=?,seen=? WHERE id=?',(json.dumps(state),stamp(),did))
            device=self.store.one('SELECT * FROM devices WHERE id=?',(did,))
            self.store.event(device,'demo_seed',{'note':'预置演示数据，并非真实长期使用记录'})
    def own(self,table,id,owner):
        if table not in {'memories','designs','instances','devices'}:raise ValueError('Invalid table')
        row=self.store.one(f'SELECT * FROM {table} WHERE id=? AND owner=?',(id,owner))
        if not row:raise APIError(404,'记录不存在或无权访问')
        return row
    def design(self,id,owner):
        row=self.store.one('SELECT d.*,u.name AS author FROM designs d JOIN users u ON u.id=d.owner WHERE d.id=? AND (d.owner=? OR d.public=1)',(id,owner))
        if not row:raise APIError(404,'设计不存在或未公开')
        return self.safe_design(row,owner)
    def safe_design(self,row,owner):
        row=dict(row); row['is_owner']=row['owner']==owner
        row['asset_url']=f"/api/designs/{row['id']}/asset/crown.stl" if row['asset'] and (self.data/row['asset']/'crown.stl').exists() else None
        row['raw_url']=f"/api/designs/{row['id']}/asset/raw.glb" if row['asset'] and (self.data/row['asset']/'raw.glb').exists() else None
        row['parameters']=None
        if row['asset'] and (self.data/row['asset']/'parameters.json').exists():row['parameters']=json.loads((self.data/row['asset']/'parameters.json').read_text())
        row['source_label']='参数化演示 · 非 Tripo 生成' if row['provider']=='parametric' else 'Tripo API · 实际任务'
        # Share design instructions, never the source memory or private operational details.
        for key in ['asset','idempotency_key','next_run','attempts']:row.pop(key,None)
        if not row['is_owner']:
            for key in ['memory_id','task_id','error','review_note']:row.pop(key,None)
        return row
    def snapshot(self,owner):
        designs=[self.safe_design(r,owner) for r in self.store.all('SELECT d.*,u.name AS author FROM designs d JOIN users u ON u.id=d.owner WHERE d.owner=? ORDER BY d.created DESC',(owner,))]
        public=[self.safe_design(r,owner) for r in self.store.all('SELECT d.*,u.name AS author FROM designs d JOIN users u ON u.id=d.owner WHERE d.public=1 ORDER BY d.created DESC LIMIT 100')]
        devices=self.store.all('SELECT id,name,kind,reported,seen,created FROM devices WHERE owner=? ORDER BY created',(owner,))
        for d in devices:
            d['reported']=json.loads(d['reported']);d['online']=stamp()-d['seen']<15
            d['commands']=self.store.all("SELECT id,kind,state,error,created FROM commands WHERE device_id=? ORDER BY created DESC LIMIT 5",(d['id'],))
        events=self.store.all('SELECT e.* FROM events e JOIN devices d ON d.id=e.device_id WHERE d.owner=? ORDER BY e.created DESC,e.rowid DESC LIMIT 50',(owner,))
        for e in events:e['payload']=json.loads(e['payload'])
        return {'memories':self.store.all('SELECT * FROM memories WHERE owner=? ORDER BY created DESC',(owner,)),
                'designs':designs,'garden':public,'instances':self.store.all('SELECT i.*,d.title AS design_title,d.theme,d.provider FROM instances i JOIN designs d ON d.id=i.design_id WHERE i.owner=? ORDER BY i.created DESC',(owner,)),
                'devices':devices,'events':events,'favorites':[r['design_id'] for r in self.store.all('SELECT design_id FROM favorites WHERE owner=?',(owner,))],
                'capabilities':{'demo':self.demo,'tripo_configured':bool(os.getenv('TRIPO_API_KEY')),'openscad':bool(shutil.which('openscad')),'interface':INTERFACE},'server_time':stamp()}
    def create_memory(self,owner,p):
        id=uid();self.store.execute('INSERT INTO memories VALUES(?,?,?,?,?,?)',(id,owner,text(p.get('title'),'标题',1,80),text(p.get('body'),'记忆',1,4000),theme(p.get('theme','forest')),stamp()));return {'id':id}
    def edit_memory(self,owner,id,p):
        self.own('memories',id,owner);self.store.execute('UPDATE memories SET title=?,body=?,theme=? WHERE id=?',(text(p.get('title'),'标题',1,80),text(p.get('body'),'记忆',1,4000),theme(p.get('theme')),id));return {'ok':True}
    def create_design(self,owner,p,key):
        key=text(key,'幂等键',8,100)
        previous=self.store.one('SELECT id FROM designs WHERE owner=? AND idempotency_key=?',(owner,key))
        if previous:return {'id':previous['id'],'reused':True}
        title=text(p.get('title'),'标题',1,80); prompt=text(p.get('prompt'),'视觉描述',3,2000); th=theme(p.get('theme','forest'))
        provider=p.get('provider','parametric')
        if provider not in {'parametric','tripo'}:raise APIError(400,'未知生成器')
        if provider=='tripo' and (not os.getenv('TRIPO_API_KEY') or p.get('accept_charges') is not True):raise APIError(400,'先配置 Tripo API Key，并确认可能产生的 API 费用')
        if provider=='parametric' and not self.demo:raise APIError(400,'参数化演示模式未启用')
        if self.store.one("SELECT COUNT(*) AS n FROM designs WHERE owner=? AND status IN ('queued','submitting','generating','polling','downloading')",(owner,))['n']>=3:raise APIError(429,'最多同时运行 3 个生成任务')
        mid=p.get('memory_id') or None; source=p.get('source_id') or None
        if mid:self.own('memories',mid,owner)
        if source:self.design(source,owner)
        id=uid();seed=secrets.randbelow(2**31)
        try:self.store.execute('INSERT INTO designs(id,owner,title,prompt,theme,seed,source_id,memory_id,provider,status,created,idempotency_key) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
            (id,owner,title,prompt,th,seed,source,mid,provider,'queued',stamp(),key))
        except sqlite3.IntegrityError:
            previous=self.store.one('SELECT id FROM designs WHERE owner=? AND idempotency_key=?',(owner,key))
            if previous:return {'id':previous['id'],'reused':True}
            raise
        return {'id':id}
    def review_design(self,owner,id,p):
        row=self.own('designs',id,owner)
        if row['status'] not in {'needs_review','reviewed'} or not row['asset']:raise APIError(409,'请等待生成和文件准备完成')
        if p.get('acknowledge') is not True:raise APIError(400,'请确认这不是实物安全认证')
        note=text(p.get('note'),'检查记录',8,2000)
        self.store.execute("UPDATE designs SET status='reviewed',review_note=? WHERE id=?",(note,id));return {'ok':True}
    def publish_design(self,owner,id,p):
        row=self.own('designs',id,owner)
        if p.get('public') is True:
            if row['status']!='reviewed':raise APIError(409,'先完成人工检查记录')
            if p.get('confirm_rights') is not True:raise APIError(400,'请确认你有权公开设计，并同意 CC BY 4.0；私人记忆不会发布')
        self.store.execute('UPDATE designs SET public=? WHERE id=?',(int(p.get('public') is True),id));return {'ok':True}
    def recover_task(self,owner,id,p):
        row=self.own('designs',id,owner)
        if row['provider']!='tripo' or row['status'] not in {'submission_unknown','failed'}:raise APIError(409,'只有异常 Tripo 任务可恢复')
        task=text(p.get('task_id'),'Tripo 任务 ID',8,100)
        if not re.fullmatch(r'[A-Za-z0-9_-]+',task):raise APIError(400,'任务 ID 格式错误')
        self.store.execute("UPDATE designs SET task_id=?,status='polling',next_run=0,error=NULL,attempts=0 WHERE id=?",(task,id));return {'ok':True}
    def create_instance(self,owner,p):
        row=self.own('designs',p.get('design_id'),owner)
        if row['status']!='reviewed':raise APIError(409,'先保存设计检查记录')
        id=uid();self.store.execute('INSERT INTO instances(id,owner,design_id,name,tag_payload,created) VALUES(?,?,?,?,?,?)',
            (id,owner,row['id'],text(p.get('name',row['title']),'名称',1,100),'BLM1:'+id,stamp()));return {'id':id}
    def stage_instance(self,owner,id,p):
        row=self.own('instances',id,owner); stage=p.get('stage')
        transitions={'planned':'printed','printed':'verified'}
        if transitions.get(row['stage'])!=stage:raise APIError(409,'请按制作 → 已打印 → 装配检查通过的顺序记录')
        if p.get('acknowledge') is not True:raise APIError(400,'必须确认已实际完成；演示可改用模拟绑定')
        self.store.execute('UPDATE instances SET stage=?,simulated=0 WHERE id=?',(stage,id));return {'ok':True}
    def command(self,owner,device_id,kind,payload,ttl=60):
        d=self.own('devices',device_id,owner);id=uid()
        if kind=='light':
            if not isinstance(payload.get('power'),bool):raise APIError(400,'power 须为布尔值')
            payload={'power':payload['power'],'brightness':integer(payload.get('brightness'),0,100,'亮度'),
                     'projection':integer(payload.get('projection',0),0,35,'投影亮度'),'theme':theme(payload.get('theme','sunflower'))}
            # Latest desired light state supersedes unacknowledged older commands.
            self.store.execute("UPDATE commands SET state='superseded' WHERE device_id=? AND kind='light' AND state='queued'",(device_id,))
        self.store.execute('INSERT INTO commands(id,device_id,kind,payload,created,expires) VALUES(?,?,?,?,?,?)',(id,d['id'],kind,json.dumps(payload),stamp(),stamp()+ttl))
        return {'id':id,'state':'queued','message':'等待设备执行回执；网页未提前宣称成功'}
    def bind_instance(self,owner,id,p):
        row=self.own('instances',id,owner);d=self.own('devices',p.get('device_id'),owner)
        if d['kind']=='esp32' and row['stage'] not in {'verified','bound'}:raise APIError(409,'真实设备绑定前必须记录实物装配检查')
        if self.store.one("SELECT id FROM commands WHERE device_id=? AND kind='bind' AND state='queued' AND expires>?",(d['id'],stamp())):raise APIError(409,'已有绑定等待完成')
        des=self.own('designs',row['design_id'],owner)
        return self.command(owner,d['id'],'bind',{'instance_id':id,'tag_payload':row['tag_payload'],'theme':des['theme']},90)
    def device_auth(self,token):
        d=self.store.one('SELECT * FROM devices WHERE token=?',(hash_secret(token),))
        if not d:raise APIError(401,'设备凭据无效')
        return d
    def handle_device_events(self,device,events):
        if not isinstance(events,list) or len(events)>16:raise APIError(400,'事件批次无效')
        for e in events:
            if not isinstance(e,dict):raise APIError(400,'事件须为对象')
            eid=text(e.get('id'),'事件 ID',8,100); kind=e.get('kind');p=e.get('payload',{})
            if not isinstance(p,dict):raise APIError(400,'事件格式错误')
            existing=self.store.one('SELECT device_id FROM events WHERE id=?',(eid,))
            if existing:
                if existing['device_id']!=device['id']:raise APIError(409,'事件 ID 冲突')
                continue
            if kind=='tag_bound':
                instance=self.own('instances',p.get('instance_id'),device['owner'])
                pending=self.store.one("SELECT * FROM commands WHERE device_id=? AND kind='bind' AND state='queued' AND expires>? ORDER BY created DESC LIMIT 1",(device['id'],stamp()))
                if not pending or json.loads(pending['payload']).get('instance_id')!=instance['id'] or p.get('verified') is not True:raise APIError(409,'绑定事件缺少对应的有效命令或读回校验')
                self.store.execute("UPDATE instances SET stage='bound',tag_uid=?,simulated=? WHERE id=?",(text(p.get('tag_uid'),'标签 UID',4,40),int(device['kind']=='simulator'),instance['id']))
            elif kind=='outfit_installed':
                instance=self.own('instances',p.get('instance_id'),device['owner'])
                if instance['stage']!='bound':raise APIError(409,'外装尚未绑定')
                if device['kind']=='esp32' and instance['simulated']:raise APIError(409,'演示绑定不能代替真实 NFC 写入')
            elif kind not in {'button','safety_trip','boot','unknown_tag','tag_write_failed','projection_timeout'}:raise APIError(400,'未知设备事件')
            self.store.event(device,kind,p,eid)
    def poll_device(self,device,p):
        self.handle_device_events(device,p.get('events',[]))
        acks=p.get('acks',[])
        if not isinstance(acks,list) or len(acks)>16:raise APIError(400,'回执格式无效')
        for a in acks:
            if not isinstance(a,dict):raise APIError(400,'回执须为对象')
            if not isinstance(a.get('ok'),bool):raise APIError(400,'回执 ok 须为布尔值')
            self.store.execute("UPDATE commands SET state=?,error=? WHERE id=? AND device_id=? AND state='queued'",
                ('acked' if a['ok'] else 'failed',str(a.get('error',''))[:200],a.get('id'),device['id']))
        reported=p.get('reported')
        if reported is not None:
            if not isinstance(reported,dict):raise APIError(400,'设备状态格式无效')
            # Do not permit the device to submit arbitrary private/operational data.
            clean={k:v for k,v in reported.items() if k in {'power','brightness','projection','theme','instance_id','temperature_c','fault','firmware','rssi'}}
            if 'brightness' in clean:integer(clean['brightness'],0,100,'亮度')
            if 'projection' in clean:integer(clean['projection'],0,35,'投影')
            if clean.get('theme'):theme(clean['theme'])
            if 'power' in clean and not isinstance(clean['power'],bool):raise APIError(400,'状态 power 须为布尔值')
            if clean.get('instance_id'):
                instance=self.own('instances',clean['instance_id'],device['owner'])
                if device['kind']=='esp32' and (instance['simulated'] or instance['stage']!='bound'):raise APIError(409,'真实设备不能上报模拟或未绑定外装')
            self.store.execute('UPDATE devices SET reported=?,seen=? WHERE id=?',(json.dumps(clean),stamp(),device['id']))
        else:self.store.execute('UPDATE devices SET seen=? WHERE id=?',(stamp(),device['id']))
        self.store.execute("UPDATE commands SET state='expired',error='设备未在有效期内确认' WHERE state='queued' AND expires<=?",(stamp(),))
        commands=self.store.all("SELECT id,kind,payload,expires FROM commands WHERE device_id=? AND state='queued' ORDER BY created LIMIT 8",(device['id'],))
        for cmd in commands:cmd['payload']=json.loads(cmd['payload'])
        known=self.store.all("SELECT i.id AS instance_id,i.tag_payload,d.theme FROM instances i JOIN designs d ON d.id=i.design_id WHERE i.owner=? AND i.stage='bound' AND (i.simulated=0 OR ?='simulator') ORDER BY i.created DESC LIMIT 16",(device['owner'],device['kind']))
        return {'commands':commands,'known_tags':known,'server_time':stamp(),'protocol':'bloom-device-v1'}
    def simulator_tick(self):
        if not self.demo:return
        for d in self.store.all("SELECT * FROM devices WHERE kind='simulator'"):
            state=json.loads(d['reported']); commands=self.store.all("SELECT * FROM commands WHERE device_id=? AND state='queued' AND expires>? ORDER BY created",(d['id'],stamp()))
            events=[];acks=[]
            for c in commands:
                p=json.loads(c['payload'])
                if c['kind']=='light':state.update(p)
                elif c['kind']=='bind':events.append({'id':'sim-'+c['id'],'kind':'tag_bound','payload':{'instance_id':p['instance_id'],'verified':True,'tag_uid':'SIM-'+p['instance_id'][:12]}})
                acks.append({'id':c['id'],'ok':True})
            self.poll_device(d,{'reported':state,'events':events,'acks':acks})
    def simulator_install(self,owner,device_id,instance_id):
        d=self.own('devices',device_id,owner)
        if not self.demo or d['kind']!='simulator':raise APIError(403,'只有明确标注的模拟设备可使用此操作')
        i=self.own('instances',instance_id,owner)
        if i['stage']!='bound':raise APIError(409,'先完成模拟绑定')
        des=self.own('designs',i['design_id'],owner);state=json.loads(d['reported'])
        if state.get('instance_id')==i['id']:return {'ok':True,'deduplicated':True}
        state.update({'instance_id':i['id'],'theme':des['theme'],'power':True})
        self.poll_device(d,{'reported':state,'events':[{'id':uid(),'kind':'outfit_installed','payload':{'instance_id':i['id']}}]})
        return {'ok':True}
    def asset_file(self,owner,id,name):
        row=self.design(id,owner);raw=self.store.one('SELECT asset FROM designs WHERE id=?',(id,))
        allowed={'crown.stl','raw.glb','raw.stl','mesh-report.json','parameters.json','interface.json','adaptation.scad','adapter-report.json'}
        if name not in allowed or not raw['asset']:raise APIError(404,'文件不存在')
        target=self.data/raw['asset']/name
        if not target.is_file():raise APIError(404,'文件尚未生成')
        return target
    def manufacture_package(self,owner,id):
        row=self.design(id,owner);raw=self.store.one('SELECT * FROM designs WHERE id=?',(id,))
        if not raw['asset']:raise APIError(409,'生成任务尚未完成')
        directory=self.data/raw['asset'];result=io.BytesIO()
        with zipfile.ZipFile(result,'w',zipfile.ZIP_DEFLATED) as z:
            for path in directory.iterdir():
                if path.is_file() and path.suffix in {'.stl','.glb','.json','.scad'}:z.write(path,path.name)
            manifest={k:row.get(k) for k in ['id','title','theme','provider','source_id','author','license','status']}
            manifest.update({'units':'mm','interface':'bloom-clamp-v1','physical_validation':False,'sha256':{p.name:__import__('hashlib').sha256(p.read_bytes()).hexdigest() for p in directory.iterdir() if p.is_file()}})
            z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            for file in ['hardware/cad/lamp.scad','hardware/cad/interface.json','docs/PRINT_AND_ASSEMBLY.md','docs/HEYGEARS_WORKFLOW.md']:
                path=ROOT/file
                if path.exists():z.write(path,file)
            for path in (ROOT/'hardware/exports').glob('gobo_*'):z.write(path,'gobos/'+path.name)
            z.writestr('READ_FIRST.txt','BLOOM 制造草案\n这不是打印成功证明。先检查 mesh-report、接口尺寸、材料与温度。\nHeyGears 导入、切片、打印及后处理由操作员完成。\nraw.glb 是生成原稿，不等同于可制造外装。crown.stl（若存在）为接口适配草案。\n本包不含用户原始私人记忆。\n')
        return result.getvalue()
    def adapt_live_model(self,directory):
        raw=glb_triangles(directory/'raw.glb')
        # Tripo commonly returns Y-up. Convert to Z-up, fit XY, flatten depth.
        transformed=[[(v[0],-v[2],v[1]) for v in t] for t in raw]
        points=[v for t in transformed for v in t]
        lo=[min(v[i] for v in points) for i in range(3)]; hi=[max(v[i] for v in points) for i in range(3)]
        width=max(hi[0]-lo[0],hi[1]-lo[1]);depth=hi[2]-lo[2]
        if min(width,depth)<1e-9:raise ValueError('Degenerate generated model')
        out=[[( (v[0]-(lo[0]+hi[0])/2)*190/width,(v[1]-(lo[1]+hi[1])/2)*190/width,4+(v[2]-lo[2])*16/depth ) for v in tri] for tri in transformed]
        write_stl(directory/'raw.stl',out)
        script='''// BLOOM interface adapter, mm. Inspect original orientation and result manually.
$fn=160;
union(){
 difference(){ cylinder(r=70,h=4); translate([0,0,-1])cylinder(r=38,h=30); }
 difference(){
  intersection(){ import("raw.stl",convexity=10); cylinder(r=98,h=24); }
  translate([0,0,-1])cylinder(r=43,h=30);
 }
}
'''
        (directory/'adaptation.scad').write_text(script)
        if not shutil.which('openscad'):
            (directory/'adapter-report.json').write_text(json.dumps({'status':'manual_required','reason':'OpenSCAD not installed; open adaptation.scad to perform Boolean crop and export'}))
            return
        completed=subprocess.run(['openscad','-o',str(directory/'crown.stl'),str(directory/'adaptation.scad')],capture_output=True,text=True,timeout=90)
        if completed.returncode or not (directory/'crown.stl').exists():raise ValueError('OpenSCAD adaptation failed; inspect raw geometry manually')
        from .geometry import read_stl
        report=inspect_mesh(read_stl(directory/'crown.stl'))
        (directory/'mesh-report.json').write_text(json.dumps(report,indent=2))
        (directory/'adapter-report.json').write_text(json.dumps({'status':'draft','method':'Y-up conversion, nonuniform flattening, annular crop + fixed carrier','not_guaranteed':['component connectivity','minimum walls','aesthetics','fit','thermal safety']}))
    def job_tick(self):
        with self.job_lock:
            row=self.store.one("SELECT * FROM designs WHERE status IN ('queued','polling') AND next_run<=? ORDER BY created LIMIT 1",(stamp(),))
            if not row:return
            id=row['id'];directory=self.data/'assets'/id;directory.mkdir(parents=True,exist_ok=True)
            if row['provider']=='parametric':
                self.store.execute("UPDATE designs SET status='generating',progress=20 WHERE id=?",(id,))
                try:
                    make_crown(directory,row['prompt'],row['theme'],row['seed'])
                    self.store.execute("UPDATE designs SET status='needs_review',progress=100,asset=?,error=NULL WHERE id=?",(f'assets/{id}',id))
                except Exception as exc:self.store.execute("UPDATE designs SET status='failed',error=? WHERE id=?",(str(exc)[:500],id))
                return
            try:
                provider=Tripo()
                if not row['task_id']:
                    self.store.execute("UPDATE designs SET status='submitting',progress=5 WHERE id=?",(id,))
                    task=provider.create(row['prompt'])
                    self.store.execute("UPDATE designs SET task_id=?,status='polling',next_run=?,progress=10 WHERE id=?",(task,stamp()+3,id));return
                data=provider.poll(row['task_id']);status=data.get('status','')
                if status in {'failed','cancelled','banned','expired'}:raise RuntimeError('Tripo task ended: '+status)
                if status!='success':
                    self.store.execute("UPDATE designs SET progress=?,next_run=?,attempts=0 WHERE id=?",(min(95,max(5,int(data.get('progress',10)))),stamp()+int(os.getenv('TRIPO_POLL_SECONDS','8')),id));return
                self.store.execute("UPDATE designs SET status='downloading',progress=96 WHERE id=?",(id,))
                output=data.get('output',{}); url=output.get('model') or output.get('pbr_model') or output.get('base_model')
                if not isinstance(url,str):raise RuntimeError('No model URL in Tripo response')
                download_model(url,directory/'raw.glb')
                (directory/'interface.json').write_text(json.dumps(INTERFACE,indent=2))
                adaptation_error=None
                try:self.adapt_live_model(directory)
                except Exception as exc:
                    adaptation_error='生成原稿已保存；接口适配需人工处理：'+str(exc)[:250]
                    (directory/'adapter-report.json').write_text(json.dumps({'status':'manual_required','error':str(exc)[:300]}))
                self.store.execute("UPDATE designs SET status='needs_review',progress=100,asset=?,error=? WHERE id=?",(f'assets/{id}',adaptation_error,id))
            except SubmissionUnknown as exc:self.store.execute("UPDATE designs SET status='submission_unknown',error=? WHERE id=?",(str(exc)[:500],id))
            except Exception as exc:
                if row['task_id'] and row['attempts']<5:
                    self.store.execute("UPDATE designs SET status='polling',error=?,attempts=attempts+1,next_run=? WHERE id=?",(str(exc)[:400],stamp()+min(120,8*2**row['attempts']),id))
                else:self.store.execute("UPDATE designs SET status='failed',error=? WHERE id=?",(str(exc)[:500],id))
    def start(self):
        def run():
            while not self.stop_event.wait(0.6):
                try:self.job_tick()
                except Exception as exc:print('Worker error:',type(exc).__name__,str(exc)[:200],file=sys.stderr)
        self.worker=threading.Thread(target=run,name='bloom-worker',daemon=True);self.worker.start()
        def sim_run():
            while not self.stop_event.wait(.6):
                try:self.simulator_tick()
                except Exception as exc:print('Simulator error:',type(exc).__name__,str(exc)[:200],file=sys.stderr)
        self.sim_worker=threading.Thread(target=sim_run,name='bloom-simulator',daemon=True);self.sim_worker.start()
    def close(self):
        self.stop_event.set()
        if self.worker:self.worker.join(timeout=2)
        if self.sim_worker:self.sim_worker.join(timeout=2)
