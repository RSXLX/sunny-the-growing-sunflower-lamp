# Tripo 真实接入与生成后处理

## 配置
根目录复制 `.env.example` 为 `.env`，配置 `TRIPO_API_KEY`，重启服务。密钥仅后端使用，不放前端、制造包或日志。

默认 API base 为 `https://api.tripo3d.ai/v2/openapi`；仅接受官方 HTTPS 域名。当前项目固定 `TRIPO_MODEL_VERSION=v2.5-20250123` 作为可配置兼容基线，不声称它是最新/最优模型。实际账号是否仍支持该版本，需在控制台核实；可在环境变量改为账号支持的值。

提交 `POST /task`，type=text_to_model，关闭 texture/pbr，face_limit=20000。保存 task_id 后 `GET /task/:id`。任务 success 后取 output.model/pbr_model/base_model 链接下载，最多50MiB，只接受公网HTTPS目标，限制重定向。

**本次未配置真实 API key，没有发生付费提交。**仅测试了请求合同、无密钥拦截、未知提交停止与恢复已知任务的分支。供应商返回格式、模型可用性、实际延迟与费用需账户联调。

## 描述原则
用户原始记忆是私有记录。工作室只发送用户明确填写和确认的视觉描述；不自动拼接日记。建议生成完整、厚实、无文字、无电气结构的环形装饰：

```text
A front-facing decorative flower crown for a small desk lamp, rounded forest leaves, broad connected shapes, smooth printable surfaces, no text, no thin floating details. The central opening and precise mount will be engineered separately.
```

模型并不因为提示词提到 printable 就自动可制造。

## 接口适配
1. 保存 raw.glb 为原始证据。
2. 最小 GLB 读取器处理内置未压缩三角网格与节点变换，拒绝不支持的压缩/稀疏/骨骼资产。
3. 默认从Y-up转为Z-up，平面居中缩放至190mm，深度压至16mm并放在z=4以上。这会改变比例，必须人工检查朝向和美感。
4. 导出 raw.stl 和 adaptation.scad：圆形最大半径98mm裁切，保留中心直径76mm孔与半径38–70mm的4mm载体。
5. 有 OpenSCAD 时执行布尔并集并导出 crown.stl，计算网格基本检查；没有则标 manual_required。

**这个适配器不是通用 DFM 系统。**可能出现孤立装饰、连接面积不足、薄壁、自交或局部仅共面接触。原稿不能自动通过时用 OpenSCAD/建模工具人工加连接筋、修正朝向，再导出；首版不支持网页上传替换模型，人工文件应保存为独立制造版本并保留证据。

本地适配：

```bash
python3 tools/prepare_generated.py path/to/raw.glb path/to/output-directory
```

不支持的压缩模型应先在建模工具中转换为未压缩嵌入式 GLB。不要仅把扩展名改成 STL。OpenSCAD CLI 必须在 PATH；Mac 可将 `/Applications/OpenSCAD.app/Contents/MacOS` 加入当前终端 PATH。

## 费用与失败策略
浏览器每次新提交用幂等键；相同键重试只返回同一设计ID。HTTP POST结果不明或进程在提交后中断，不自动再POST。到Tripo控制台核实是否已扣费并拿到任务ID，在衣橱「恢复任务」中继续查询。

已经知道task_id的查询/下载采用有限重试。任务失败不会自动调用另一家付费服务，也不偷偷回退成假AI结果。
