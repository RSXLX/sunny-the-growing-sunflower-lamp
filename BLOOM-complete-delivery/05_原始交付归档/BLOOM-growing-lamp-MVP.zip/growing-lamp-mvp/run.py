#!/usr/bin/env python3
"""Start BLOOM. No pip or npm installation needed for the default local MVP."""
from app.server import main
if __name__=='__main__':main()
