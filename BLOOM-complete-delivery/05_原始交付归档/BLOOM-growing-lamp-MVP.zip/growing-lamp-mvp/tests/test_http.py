"""Actual localhost HTTP contracts, authentication, same-origin and CSRF."""
import http.cookiejar,json,os,tempfile,threading,unittest,urllib.request,urllib.error
from app.server import BloomServer
from app.service import Service

class HttpTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  os.environ['QUIET']='1';cls.tmp=tempfile.TemporaryDirectory();cls.service=Service(cls.tmp.name,True);cls.server=BloomServer(('127.0.0.1',0),cls.service);cls.url='http://127.0.0.1:'+str(cls.server.server_port);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
  cls.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));status,data,headers=cls.call('/api/auth/login','POST',{'email':'alice@bloom.local','password':'BloomDemo!2026'});cls.csrf=data['csrf'];cls.cookie=headers['Set-Cookie']
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.service.close();cls.tmp.cleanup()
 @classmethod
 def call(cls,path,method='GET',body=None,headers=None,anonymous=False):
  req=urllib.request.Request(cls.url+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json',**(headers or {})},method=method)
  try:res=(urllib.request.urlopen(req,timeout=5) if anonymous else cls.opener.open(req,timeout=5))
  except urllib.error.HTTPError as e:res=e
  raw=res.read();data=json.loads(raw) if 'application/json' in res.headers.get('Content-Type','') else raw
  return res.code,data,dict(res.headers)
 def test_01_root_and_assets(self):
  for path in ['/','/app.js','/viewer.js','/style.css','/wiring.svg','/favicon.svg']:self.assertEqual(self.call(path)[0],200)
 def test_02_requires_authentication(self):self.assertEqual(self.call('/api/state',anonymous=True)[0],401)
 def test_03_cookie_security(self):self.assertIn('HttpOnly',self.cookie);self.assertIn('SameSite=Strict',self.cookie)
 def test_04_csrf_required(self):self.assertEqual(self.call('/api/memories','POST',{'title':'t','body':'b','theme':'forest'})[0],403)
 def test_05_memory_write_read_delete(self):
  status,m,_=self.call('/api/memories','POST',{'title':'HTTP memory','body':'Saved through real HTTP','theme':'forest'},{'X-CSRF-Token':self.csrf});self.assertEqual(status,201);self.assertTrue(any(x['id']==m['id'] for x in self.call('/api/state')[1]['memories']));self.assertEqual(self.call('/api/memories/'+m['id'],'DELETE',{}, {'X-CSRF-Token':self.csrf})[0],200)
 def test_06_cross_origin_write(self):self.assertEqual(self.call('/api/memories','POST',{}, {'Origin':'https://evil.example','X-CSRF-Token':self.csrf})[0],403)
 def test_07_host_rebinding_rejected(self):self.assertEqual(self.call('/api/health',headers={'Host':'evil.example'})[0],403)
 def test_08_traversal_rejected(self):self.assertEqual(self.call('/%2e%2e/app/store.py')[0],404)
 def test_09_device_bearer_required(self):self.assertEqual(self.call('/api/device/poll','POST',{},anonymous=True)[0],401)
 def test_10_create_real_device_protocol(self):
  code,d,_=self.call('/api/devices','POST',{'name':'HTTP test device'},{'X-CSRF-Token':self.csrf});self.assertEqual(code,201)
  code,data,_=self.call('/api/device/poll','POST',{'reported':{'power':False,'brightness':0,'projection':0,'theme':'forest','temperature_c':25.0}},{'Authorization':'Bearer '+d['token']},True);self.assertEqual(code,200);self.assertEqual(data['protocol'],'bloom-device-v1')
 def test_11_security_headers(self):
  _,_,h=self.call('/');self.assertEqual(h['X-Content-Type-Options'],'nosniff');self.assertIn("script-src 'self'",h['Content-Security-Policy'])
 def test_12_bad_login_rejected(self):self.assertEqual(self.call('/api/auth/login','POST',{'email':'alice@bloom.local','password':'not-correct'},anonymous=True)[0],401)

if __name__=='__main__':unittest.main()
