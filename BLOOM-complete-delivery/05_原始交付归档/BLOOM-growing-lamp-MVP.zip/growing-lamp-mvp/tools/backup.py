#!/usr/bin/env python3
"""Stop the app first for a consistent database + asset snapshot."""
import argparse,datetime,json,shutil,sqlite3
from pathlib import Path
from contextlib import closing
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,default=Path('data'));p.add_argument('--out',type=Path,default=Path('backups'));a=p.parse_args()
source=a.data/'bloom.sqlite3'
if not source.is_file():raise SystemExit('No database found in '+str(a.data))
target=a.out/('bloom-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));target.mkdir(parents=True,exist_ok=False)
with closing(sqlite3.connect(source)) as src,closing(sqlite3.connect(target/'bloom.sqlite3')) as dst:src.backup(dst)
if (a.data/'assets').is_dir():shutil.copytree(a.data/'assets',target/'assets')
(target/'README.txt').write_text('Contains PRIVATE user data and account hashes. Store securely. Restore database and assets together. Stop application for a cross-resource consistent backup.\n')
print(target.resolve())
